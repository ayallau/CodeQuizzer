export interface Topic {
  _id: string;
  title: string;
  description: string;
  color: string;
  icon: string;
} 