import { Component } from '@angular/core';
import { LoginComponent } from '../../components/auth/login/login.component';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome-page.component.html',
  styleUrls: ['./welcome-page.component.css']
})
export class WelcomePageComponent {

}
