import { Component } from '@angular/core';

@Component({
    selector: 'app-reset-password-page',
    templateUrl: './reset-password-page.component.html',
    styleUrls: ['./reset-password-page.component.css']
})
export class ResetPasswordPageComponent { }
