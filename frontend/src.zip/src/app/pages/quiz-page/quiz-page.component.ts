import { Component } from '@angular/core';

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz-page.component.html',
  styleUrls: ['./quiz-page.component.css']
})
export class QuizPageComponent {

}
